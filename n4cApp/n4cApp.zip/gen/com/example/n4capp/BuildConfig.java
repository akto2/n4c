/** Automatically generated file. DO NOT MODIFY */
package com.example.n4capp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}