	$('.fa-bars').click(function(e) {
		e.preventDefault();
		location.href = "list.html";
	});

	$('.fa-user').click(function(e) {
		e.preventDefault();
		location.href = "user.html";
	});
	
	$('#Chatbox').click(function(e) {
		e.preventDefault();
		location.href = "writing.html";
	});
	
	$('.fav').on("click", function(e) {
		alert("chk");
		e.preventDefault();
		//location.href = "log-in.html";
	});
	
	/*$('.fa-user').click(function(e) {
		e.preventDefault();
		location.href = "log-in.html";
	});*/
	
	$('#singup').click(function(e) {
		e.preventDefault();
		location.href = "Registration.html";
	});
	
	$('#login').click(function(e) {
		e.preventDefault();
		location.href = "user.html";
	});
	
